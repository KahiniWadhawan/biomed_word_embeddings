# Convert the covered files, so that each pair also has the mean score
# The mean score for  coverdRelatedPairs.csv and coverdSimilarPairs.csv
# will be taken from the original files

# The mean score for coverdAnalogyPairs.csv and coverdBmassPairs.csv
# will be set to 100 by default as they were taken from analogies and BMASS dataset

The coveredPairs.csv contains pairs from all other files
along with their mean values.

The mean values for term=pairs in coverdAnalogyPairs.csv and coverdBmassPairs.csv are set to 100.0