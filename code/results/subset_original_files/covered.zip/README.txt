This archive contains pairs of terms that are found to appear in our ontology corpus.
The contents are the covered subsets of respective datasets:

1. coverdAnalogyPairs.csv - Analogies.txt
2. coverdBmassPairs.csv - BMASS_all_info.txt
3. coverdMayoPairs.csv - MayoSRS.csv
4. coverdRelatedPairs.csv - UMNSRS_relatedness_mod458_word2vec.csv
5. coverdSimilarPairs.csv - UMNSRS_similarity_mod449_word2vec.csv
6. coverdPairs.csv - the union of all the above (if required)
